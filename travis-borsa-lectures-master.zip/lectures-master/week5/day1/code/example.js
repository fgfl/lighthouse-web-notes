const database = {
  books: [
    {
      title: 'Name of the Wind',
      author: 'Patrick Rothfuss',
      year: 2007
    },
    {
      title: 'Dune',
      author: 'Frank HErbert',
      year: 1865
    },
    {
      title: '1984',
      author: 'George Orwell',
      year: 1984
    },
    {
      name: 'The fellowship of the ring',
      writer: 'JRR tolkein',
      year: '12/15/1980'
    }
  ],

  people: [
    {
      name: 'travis',
      favortie_books: ['Dune', "the hobbit", 'Red rising']
    }
  ]
}