

- Other hooks that are available
  - useState
  - useReducer
  - useEffect

  - useContext 

- React component libraries/ react libraries
  - component libraries stylized UI
  - component libraries for functional specific things
  - make quality of life improvements

- React router
  - renders componenets based on paths
  - updates the dom path based on our user navigation

- React from scratch
  - 

- Redux
  - 

- Typescript 

