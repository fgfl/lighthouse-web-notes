$pitbull = 'mr worldwide'

thing = 'test'

def my_method 
  puts thing

end

my_method