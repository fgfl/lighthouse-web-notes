# lectures
A place for all the notes and code from my computer science lectures. 